



window.alert("THIS IS AN ALERTING MESSAGE");

document.write("This is the write function");

console.table(output);

try {
    document.getElementById("output").innerHTML = "HELLO WORLD";
    console.log("ok");
}
catch (err){
    console.log("an error has occured in the above statement");

}



try {
   console.log("No Problem");
}
catch (err) {
    console.log("There was a probelm");

}
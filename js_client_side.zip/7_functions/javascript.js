function clickMe() {
    document.write("First page");
}

function clickMe2() {
    document.write("Second page");
}
function clickMe3() {
    document.write("Third page");
}
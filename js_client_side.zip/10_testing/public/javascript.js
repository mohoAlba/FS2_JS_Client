function clickMe() {
    
    
}
function clickMeAgain () {
    document.write("You clicked the button on the second page");
    document.write(Date());

}
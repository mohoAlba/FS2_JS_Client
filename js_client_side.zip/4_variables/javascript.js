
try {
var names = ["James", "Kevin", "Katen"];
var numbers = [1,2,3];

console.log("sucess");
console.log(names[0] + numbers[0], names[1] + numbers[1], names[2] + numbers[2]);
document.write(names[0] + numbers[0], names[1] + numbers[1], names[2] + numbers[2]);

}
catch (err) {
    console.log("There was a problem");
}
